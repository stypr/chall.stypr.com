<div class="jumbotron">
<br>
<img src='/images/main.jpg' align='center'>
</div>

<div class="row">
	<div class="col-lg-4">
		<h2>About Eagle Jump?</h2>
		<p>Eagle Jump is Game Development company. It's a small company but, we are try to make funny games!</p>
		<p><a class="btn btn-primary" href="/?p=intro" role="button">View details &raquo;</a></p>
	</div>
	<div class="col-lg-4">
		<h2>Notice</h2>
		<p>Message from our company, about bug, patchlog etc.</p>
		<p><a class="btn btn-primary" href="/?p=board" role="button">View details &raquo;</a></p>
	</div>
	<div class="col-lg-4">
		<h2>Contact</h2>
		<p>If you need to contact for bug reporting or other reason, please use this menu</p>
		<p><a class="btn btn-primary" href="/?p=contact" role="button">View details &raquo;</a></p>
	</div>
</div>
