<?php
	#DEVELOPER ONLY
	if($_GET['KEY'] === md5($master_key))
		phpinfo();
	else
		echo "DEVELOPER ONLY";
?>
