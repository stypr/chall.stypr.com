<form class="form-signin" action='./login_chk.php' method='post'>
	<h2 class="form-signin-heading">LOGIN</h2>
	<label for="ID" class="sr-only">ID</label>
	<input type="text" name="id" class="form-control" placeholder="ID" required autofocus>
	<label for="inputPassword" class="sr-only">Password</label>
	<input type="password" name="pw" class="form-control" placeholder="Password" required>
	<button class="btn btn-lg btn-primary btn-block" type="submit">LOGIN</button>
</form>

<!-- HERE IS GUEST ACCOUNT

ID : guest
PW : guest

HAPPY HACKING!
-->
