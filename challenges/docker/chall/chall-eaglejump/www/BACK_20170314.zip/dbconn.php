<?php
	$db_name = '----hidden----';
	$db_user = '----hidden----';
	$db_pass = '----hidden----';
	$dbconn = mysqli_connect('localhost',$db_user,$db_pass,$db_name);

	$q = "SELECT table_name FROM information_schema.tables where table_type='base table' limit 0,1";
	$table = mysqli_fetch_array(mysqli_query($dbconn,$q))[0];
	$q = "SELECT * FROM {$table}";
	$master_key = mysqli_fetch_array(mysqli_query($dbconn,$q))[0];
?>
