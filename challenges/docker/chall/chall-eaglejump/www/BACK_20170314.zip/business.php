<link href="http://bootstrapk.com/examples/carousel/carousel.css" rel="stylesheet">
<div class="container marketing">
	<div class="row">
		<div class="col-lg-4">
			<img class="img-circle" src="./images/codegate.png" alt="Generic placeholder image" width="140" height="140">
			<h2>Information Security</h2>
		</div><!-- /.col-lg-4 -->

		<div class="col-lg-4">
			<img class="img-circle" src="./images/dev.png" alt="Generic placeholder image" width="140" height="140">
			<h2>Development</h2>
		</div><!-- /.col-lg-4 -->

	    <div class="col-lg-4">
			<img class="img-circle" src="./images/research.png" alt="Generic placeholder image" width="140" height="140">
			<h2>Research</h2>
		</div><!-- /.col-lg-4 -->
	</div>
</div>
