<?php /* Smarty version Smarty-3.1.12, created on 2014-09-02 22:06:18
         compiled from "notice.html" */ ?>
<?php /*%%SmartyHeaderCode:124435255577777df91-40941871%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1f0e31c412a51430a668765682aa29b24d4dd890' => 
    array (
      0 => 'notice.html',
      1 => 1409663171,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '124435255577777df91-40941871',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_5255577782ed35_30937743',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5255577782ed35_30937743')) {function content_5255577782ed35_30937743($_smarty_tpl) {?>    <div class="container">

      <div class="row">

        <div class="col-lg-12">
          <h1 class="page-header">Notice <small>��������</small></h1>
          <ol class="breadcrumb">
            <li><a href="index.html">Ȩ</a></li>
            <li class="active">Notice</li>
          </ol>
        </div>

      </div>

      <div class="row">

        <div class="col-lg-12">

          <div class="panel-group" id="accordion">

            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                   ��������1
                  </a>
                </h4>
              </div>
              <div id="collapseOne" class="panel-collapse collapse">
                <div class="panel-body">
                 ���� ������ �ο��� ��ǥ�̻�Ƿ� ���ñ� �ٶ��ϴ�.
                </div>
              </div>
            </div>

            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                    ��������2
                  </a>
                </h4>
              </div>
              <div id="collapseTwo" class="panel-collapse collapse">
                <div class="panel-body">
                  Coooool
                </div>
              </div>
            </div>

            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
                    �޸�
                  </a>
                </h4>
              </div>
              <div id="collapseSix" class="panel-collapse collapse">
                <div class="panel-body">
                  �޸��Դϴ�.
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>

    <div class="container">
<?php }} ?>