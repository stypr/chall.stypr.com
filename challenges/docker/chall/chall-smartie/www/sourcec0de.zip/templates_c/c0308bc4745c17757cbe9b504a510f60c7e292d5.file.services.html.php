<?php /* Smarty version Smarty-3.1.12, created on 2014-09-02 22:03:50
         compiled from "services.html" */ ?>
<?php /*%%SmartyHeaderCode:1056952555773128ff5-23914877%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c0308bc4745c17757cbe9b504a510f60c7e292d5' => 
    array (
      0 => 'services.html',
      1 => 1409663025,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1056952555773128ff5-23914877',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_52555773173281_38258047',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52555773173281_38258047')) {function content_52555773173281_38258047($_smarty_tpl) {?><html>
<script>alert("Not yet");
history.go(-1);
</script>
</html><?php }} ?>