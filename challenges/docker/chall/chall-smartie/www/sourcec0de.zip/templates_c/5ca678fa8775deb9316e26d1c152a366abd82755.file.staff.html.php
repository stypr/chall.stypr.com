<?php /* Smarty version Smarty-3.1.12, created on 2014-09-02 20:15:22
         compiled from "staff.html" */ ?>
<?php /*%%SmartyHeaderCode:8922525559c4c10f07-06926252%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5ca678fa8775deb9316e26d1c152a366abd82755' => 
    array (
      0 => 'staff.html',
      1 => 1382333411,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8922525559c4c10f07-06926252',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_525559c4c58e36_71495343',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_525559c4c58e36_71495343')) {function content_525559c4c58e36_71495343($_smarty_tpl) {?>    <div class="container">
      
      <div class="row">
        <div class="col-md-3 col-sm-4 sidebar">
            <ul class="nav nav-stacked nav-pills">
			<li class="disabled"><a href="#">Staff</a></li>
              <li><a href="#">���1</a></li>
              <li><a href="#">���2</a></li>
              <li><a href="#">���3</a></li>
              <li><a href="#">���6</a></li>
              <li><a href="#">���4</a></li>
              <li><a href="#">���5</a></li>
              <li class="disabled"><a href="#">Admin</a></li>
              <li><a href="#">������1</a></li>
              <li><a href="#">������2</a></li>
            </ul>
        </div>
      
        <div class="col-md-9 col-sm-8">
          <h1 class="page-header">��� ���� ������ <small>for admin</small></h1>
          <ol class="breadcrumb">
            <li><a href="./">Ȩ</a></li>
            <li class="active">��� ������</li>
          </ol>
          <p>���� ������ ����� �����ڸ� �˼� �ֽ��ϴ�.</p>
        </div>

      </div>

    </div>
<?php }} ?>