<?php /* Smarty version Smarty-3.1.12, created on 2014-09-02 22:17:57
         compiled from "main.html" */ ?>
<?php /*%%SmartyHeaderCode:98075256596484daf2-92120777%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2d6427cfcffb5ef37b2d32bd7aac8a9b7450a987' => 
    array (
      0 => 'main.html',
      1 => 1409663869,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '98075256596484daf2-92120777',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_52565964a2fb75_21591162',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52565964a2fb75_21591162')) {function content_52565964a2fb75_21591162($_smarty_tpl) {?>   <div id="myCarousel" class="carousel slide">

        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner">
          <div class="item active">
            <div class="fill" style="background-image:url('img/collaboration-social.jpg');"></div>
            <div class="carousel-caption">
			<h1>Intranet Service</h1> 
            </div>
          </div>
          <div class="item">
            <div class="fill" style="background-image:url('img/World-of-consulting.jpg');"></div>
            <div class="carousel-caption">
			<h1>Check your service</h1> 
            </div>
          </div>
          <div class="item">
            <div class="fill" style="background-image:url('img/Business-Plan-Strategy-Paperwork.jpg');"></div>
            <div class="carousel-caption">
			<h1>Have a nice day :D</h1> 
            </div>
          </div>
        </div>
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
          <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
          <span class="icon-next"></span>
        </a>
    </div>

    <div class="section text-center">

      <div class="container">

        <div class="row">
          <div class="col-lg-12">
            <h2>intranet service</h2>
            <p>cooooooool</p>
			 <p>:)</p>
            <hr>
          </div>
        </div>

      </div>

    </div>



    <div class="section-colored">

      <div class="container">

        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-6">
            <img class="img-responsive" src="img/snowden-cyber.jpg" width="700" height="450">
          </div>
          <div class="col-lg-6 col-md-6 col-sm-6">
            <h2>intranet service Features:</h2>
            <ul>
              <li>Secure Service</li>
              <li>PHP Smarty</li>
            </ul>
          </div>
        </div>

      </div>
    </div>
<?php }} ?>