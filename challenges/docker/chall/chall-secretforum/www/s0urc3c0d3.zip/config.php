<?php
$config = array();
$config[ 'user' ] = 'secret_forum';
$config[ 'pass' ] = 'uEppBeGehaJVfJr5';
$config[ 'db' ]   = 'secret_forum';
$config[ 'host' ] = 'localhost';
?>