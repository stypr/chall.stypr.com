<?php
define("IT_IS_THE_SECRET_VALUE", "FIXME");
?>