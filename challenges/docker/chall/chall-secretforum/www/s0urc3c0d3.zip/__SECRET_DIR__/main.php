<?php
if (!defined('__DIR__')) die('');
?>
<div style='width: 70%; margin: 30px;'>
	<h1>Hello, <?php echo $_SESSION[ 'id' ] ? $_SESSION[ 'id' ] : 'World'; ?>!</h1>
	<img src='./img/asdf.png' style='border: 1px; border-style: solid;'>
	<p>In publishing and graphic design, lorem ipsum (derived from Latin dolorem ipsum, translated as "pain itself") is a filler text commonly used to demonstrate the graphic elements of a document or visual presentation. Replacing meaningful content with placeholder text allows designers to design the form of the content before the content itself has been produced.[citation needed]</p>
	<p>The lorem ipsum text is typically a scrambled section of De finibus bonorum et malorum, a 1st-century BC Latin text by Cicero, with words altered, added, and removed to make it nonsensical, improper Latin.[citation needed]</p>
	<p>A variation of the ordinary lorem ipsum text has been used in typesetting since the 1960s or earlier, when it was popularized by advertisements for Letraset transfer sheets. It was introduced to the Information Age in the mid-1980s by Aldus Corporation, which employed it in graphics and word-processing templates for its desktop publishing program PageMaker.[1][not in citation given]</p>
	<b>&lt;source: <a href='https://en.wikipedia.org/wiki/Lorem_ipsum'>https://en.wikipedia.org/wiki/Lorem_ipsum</a>&gt;</b><br />
	<span style='color: #ff0000;'>* caution: Lorem ipsum are not related to the challenge.</span>
</div>