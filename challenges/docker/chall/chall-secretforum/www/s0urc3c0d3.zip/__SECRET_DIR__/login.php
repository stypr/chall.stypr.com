
		<link rel="stylesheet" type="text/css" href="./css/login.css" />
		<div id="layout">
			<div id="container">
				<div class="center">
					<form method="POST" action="./login.php">
						<fieldset style="display: inline-block">
							<legend>Login</legend>
							<div class="login_form">
								<div class="field_wrapper_stub first">
									
								</div>
								<div class="field_wrapper first">
									
									<label for="id_username"><img alt="username" width="20" height="20" src="./img/icon_user.gif" /></label><input autofocus="" id="id_username" maxlength="254" name="username" type="text" required />
								</div>
								<div class="field_wrapper">
									
									<label for="id_password"><img alt="password" width="20" height="20" src="./img/icon_pass.gif" /></label><input id="id_password" name="password" type="password" required /><input type="submit" value="Login" class="btn2 type_b" />
								</div>
							</div>
						</fieldset>
					</form>
				</div>
			</div>
		</div>